package com.example.plantstoreuiassignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
