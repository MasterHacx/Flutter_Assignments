// lib/models/plant.dart

class Plant {
  final String name;
  final String imageUrl;
  final double price;
  final String? type; // e.g., "Indoor Plant"
  final String? category; // e.g., "Small"
  final String description; // For the detail screen

  // Stats for detail screen
  final String lightStats;
  final String waterStats;
  final String tempStats;

  Plant({
    required this.name,
    required this.imageUrl,
    required this.price,
    this.type,
    this.category,
    required this.description,
    this.lightStats = '37%', // Default values if not provided
    this.waterStats = '2-3x/week',
    this.tempStats = '25°C',
  });

  // Example static data for the assignment
  static List<Plant> dummyPlants = [
    Plant(
      name: 'Peace Lily',
      imageUrl: 'assets/images/peace-lily-spathiphyllum-plant.png',
      price: 40.00, // Updated price as per detail screen image
      type: 'Indoor Plant',
      category: 'Small',
      description:
          'The peace lily plant is well known for its air-purifying abilities as a houseplant; it\'s great at breaking down and neutralizing toxic gases like carbon... Read More',
      lightStats: '37%',
      waterStats: '2-3x/week',
      tempStats: '25°C',
    ),
    Plant(
      name: 'Orchid Cactus', // Name from Home Screen
      imageUrl:
          'assets/images/rosemary-plant.png', // Using rosemary as placeholder for Orchid Cactus
      price: 30.00,
      type: 'Indoor Plant',
      category: 'Medium',
      description:
          'A beautiful flowering cactus that adds vibrant color to your home. Requires bright indirect light and moderate watering.',
    ),
    Plant(
      name: 'Zanzibar Gem', // Name from Home Screen
      imageUrl:
          'assets/images/Air-purifier-money-plant.png', // Using money plant as placeholder for Zanzibar Gem
      price: 25.00,
      type: 'Indoor Plant',
      category: 'Medium',
      description:
          'The Zanzibar Gem is an incredibly hardy plant, tolerant of neglect and low light. Perfect for beginners!',
    ),
    Plant(
      name: 'Pothos', // Name from Home Screen
      imageUrl:
          'assets/images/plants-syngonium-pink-plant.png', // Using syngonium as placeholder for Pothos
      price: 36.00,
      type: 'Indoor Plant',
      category: 'Large',
      description:
          'Pothos are popular for their trailing vines and variegated leaves. They are easy to care for and can purify air.',
    ),
    Plant(
      name: 'Areca Palm',
      imageUrl: 'assets/images/areca-palm-small-plant.png',
      price: 45.00,
      type: 'Outdoor Plant',
      category: 'Large',
      description:
          'The Areca Palm is a beautiful feathery palm often used indoors. It prefers bright, indirect light and moist soil.',
    ),
    Plant(
      name: 'Miniature Rose',
      imageUrl: 'assets/images/miniature-rose-button-rose-any-color-plant.png',
      price: 30.00,
      type: 'Outdoor Plant',
      category: 'Small',
      description:
          'Miniature roses are delicate and charming, perfect for patios or small gardens. They require full sun and regular watering.',
    ),
  ];
}
