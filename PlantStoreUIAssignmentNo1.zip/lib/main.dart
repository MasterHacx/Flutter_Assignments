// lib/main.dart

import 'package:flutter/material.dart';
import 'home_screen.dart'; // Import your home screen file

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Plant Store UI',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: const HomeScreen(), // Display our HomeScreen
      debugShowCheckedModeBanner: false, // Hides the "DEBUG" banner
    );
  }
}
