// lib/data/dummy_data.dart

import '../models/product.dart'; // Correct relative import

List<Product> dummyProducts = [
  Product(
    id: 'p1',
    name: 'Farm Fresh Produce',
    imageUrl: 'assets/images/farm_fresh_produce.png',
    price: 10.00,
    discount: 5,
    rating: 3.5,
    deliveryTime: '10 min',
    description:
        'Enjoy farm-fresh produce, handpicked for quality, packed with nutrition, and delivered with care! See more...',
  ),
  Product(
    id: 'p2',
    name: 'Organic Oats',
    imageUrl: 'assets/images/oats.png',
    price: 4.50,
    discount: 0,
    rating: 4.8,
    deliveryTime: '15 min',
    description:
        'High-quality organic oats, perfect for a healthy breakfast or baking.',
  ),
  Product(
    id: 'p3',
    name: 'Fresh Avocados',
    imageUrl: 'assets/images/avocado.png',
    price: 3.20,
    discount: 10,
    rating: 4.2,
    deliveryTime: '20 min',
    description:
        'Creamy and ripe avocados, great for guacamole, salads, or toast.',
  ),
  Product(
    id: 'p4',
    name: 'Sweet Mangoes',
    imageUrl: 'assets/images/mango.png',
    price: 2.75,
    discount: 0,
    rating: 4.5,
    deliveryTime: '10 min',
    description:
        'Juicy and sweet mangoes, a tropical delight perfect for snacks or desserts.',
  ),
  Product(
    id: 'p5',
    name: 'Fresh Milk 1L',
    imageUrl: 'assets/images/milk.png',
    price: 2.99,
    discount: 0,
    rating: 4.0,
    deliveryTime: '25 min',
    description:
        'Nutritious and delicious fresh milk, essential for your daily needs.',
  ),
];
