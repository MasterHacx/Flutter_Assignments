// lib/main.dart

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; // Correct package import
import 'screens/home_screen.dart'; // Correct relative import
import 'screens/product_details_screen.dart'; // Correct relative import

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});

  // Configure GoRouter
  final GoRouter _router = GoRouter(
    routes: [
      GoRoute(
        path: '/',
        builder: (context, state) => const HomeScreen(),
      ),
      GoRoute(
        path: '/product/:id',
        builder: (context, state) {
          final productId = state.pathParameters['id'];
          if (productId == null) {
            // Handle error: ID not found, or navigate to a generic error screen
            return const Center(child: Text('Product ID not provided'));
          }
          return ProductDetailsScreen(productId: productId);
        },
      ),
    ],
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Grocery App UI',
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Colors.grey[50], // Consistent background
        appBarTheme: const AppBarTheme(
          color: Colors.white,
          elevation: 0,
          iconTheme: IconThemeData(color: Colors.black),
          toolbarTextStyle: TextStyle(color: Colors.black),
          titleTextStyle:
              TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
      ),
      routerConfig: _router, // Use the configured router
      debugShowCheckedModeBanner: false,
    );
  }
}
