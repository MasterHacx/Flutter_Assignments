// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart'; // Correct package import
import '../data/dummy_data.dart'; // Correct relative import
import '../widgets/bottom_nav_bar.dart'; // Correct relative import
import '../widgets/category_item.dart'; // Correct relative import
import '../widgets/product_card.dart'; // Correct relative import

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50], // Light background
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 120, // Increased height for delivery info
        flexibleSpace: Padding(
          padding: const EdgeInsets.only(top: 48.0, left: 16.0, right: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.location_on, color: Colors.green),
                  const SizedBox(width: 8),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Delivery Location',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                      const Text(
                        'Green Valley Point',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 16),
                      ),
                    ],
                  ),
                  const Spacer(),
                  // Search bar on app bar - adapting to image. Could also be in body.
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.search, color: Colors.grey),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Delivery/Pickup buttons (basic UI, no logic)
              Row(
                children: [
                  _buildDeliveryButton('Delivery', true),
                  const SizedBox(width: 10),
                  _buildDeliveryButton('Pickup', false),
                ],
              ),
            ],
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20), // Space after app bar content

            // Categories
            const Text(
              'Categories',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 100, // Fixed height for horizontal category list
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: const [
                  CategoryItem(
                      title: 'Meats', icon: Icons.fastfood, isSelected: true),
                  CategoryItem(title: 'Fresh', icon: Icons.local_florist),
                  CategoryItem(title: 'Bakery', icon: Icons.cake),
                  CategoryItem(title: 'Grains', icon: Icons.grain),
                  CategoryItem(title: 'Organic', icon: Icons.eco),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Popular Items Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Popular Items',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                TextButton(
                  onPressed: () {
                    debugPrint('See All pressed');
                  },
                  child: const Text(
                    'See All',
                    style: TextStyle(color: Colors.green),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Horizontal list of Popular Items
            SizedBox(
              height: 280, // Adjust height based on card size
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: dummyProducts.length,
                itemBuilder: (context, index) {
                  final product = dummyProducts[index];
                  return ProductCard(
                    product: product,
                    onTap: () {
                      context.go(
                          '/product/${product.id}'); // Navigate using go_router
                    },
                  );
                },
              ),
            ),

            const SizedBox(height: 24),
            // Add more sections here if needed, e.g., a second grid or list
          ],
        ),
      ),
      bottomNavigationBar: const BottomNavBar(),
    );
  }

  Widget _buildDeliveryButton(String text, bool isSelected) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: isSelected ? Colors.green : Colors.grey[200],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.black,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
