package com.example.grocery_app_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
